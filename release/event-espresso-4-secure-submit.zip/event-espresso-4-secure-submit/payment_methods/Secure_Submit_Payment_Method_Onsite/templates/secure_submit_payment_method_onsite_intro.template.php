<?php

/* 
 * Note! This file's name is critical to having EE_PMT_New_Payment_Method::introductory_html() find it and use it in the right spot.
 * This will appear before the payment method is activated, and should describe it
 */
_e( 'This payment method uses Secure Submit to process credit cards and gift cards through Heartland Payments', 'event_espresso' );
