<?php

/**
 * Class HpsACHType
 */
abstract class HpsACHType extends HpsAccountType
{
}
