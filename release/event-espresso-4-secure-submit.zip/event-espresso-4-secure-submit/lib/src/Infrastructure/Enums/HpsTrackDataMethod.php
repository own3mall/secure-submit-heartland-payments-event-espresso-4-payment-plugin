<?php

/**
 * Class HpsTrackDataMethod
 */
class HpsTrackDataMethod
{
    const SWIPE     = 'swipe';
    const PROXIMITY = 'proximity';
}
