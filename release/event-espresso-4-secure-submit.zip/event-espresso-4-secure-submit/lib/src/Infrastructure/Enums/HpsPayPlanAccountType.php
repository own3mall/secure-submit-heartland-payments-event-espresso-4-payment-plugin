<?php

/**
 * Class HpsPayPlanAccountType
 */
abstract class HpsPayPlanAccountType
{
    const BUSINESS = 'Business';
    const PERSONAL = 'Personal';
}
