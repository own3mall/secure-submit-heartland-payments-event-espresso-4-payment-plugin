<?php

/**
 * Class HpsPayPlanScheduleDuration
 */
abstract class HpsPayPlanScheduleDuration
{
    const ONGOING        = 'Ongoing';
    const END_DATE       = 'End Date';
    const LIMITED_NUMBER = 'Limited Number';
}
