<?php

/**
 * Class HpsCardBrand
 */
abstract class HpsCardBrand
{
    const MASTERCARD = 'MC';
    const AMEX       = 'Amex';
    const VISA       = 'Visa';
    const DISCOVER   = 'Disc';
}
