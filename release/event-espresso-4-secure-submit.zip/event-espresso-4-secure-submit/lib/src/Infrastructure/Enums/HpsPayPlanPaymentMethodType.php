<?php

/**
 * Class HpsPayPlanPaymentMethodType
 */
abstract class HpsPayPlanPaymentMethodType
{
    const ACH         = 'ACH';
    const CREDIT_CARD = 'Credit Card';
}
