<?php

/**
 * Class HpsDataEntryMode
 */
abstract class HpsDataEntryMode
{
    const MANUAL = 'MANUAL';
    const SWIPE  = 'SWIPE';
}
