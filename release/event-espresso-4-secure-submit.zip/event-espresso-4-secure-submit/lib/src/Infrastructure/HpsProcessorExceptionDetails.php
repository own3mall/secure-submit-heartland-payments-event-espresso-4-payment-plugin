<?php

/**
 * Class HpsProcessorExceptionDetails
 */
class HpsProcessorExceptionDetails
{
    public $processorResponseCode = null;
    public $processorResponseText = null;
}
