<?php

/**
 * Class HpsProcessorError
 */
class HpsProcessorError
{
    public $code;
    public $message;
    public $type;
}
