<?php

/**
 * Class HpsGiftCardReplace
 */
class HpsGiftCardReplace extends HpsGiftCardActivate
{
}
