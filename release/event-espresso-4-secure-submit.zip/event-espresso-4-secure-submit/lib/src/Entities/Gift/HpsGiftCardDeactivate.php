<?php

/**
 * Class HpsGiftCardDeactivate
 */
class HpsGiftCardDeactivate extends HpsGiftCardActivate
{
}
