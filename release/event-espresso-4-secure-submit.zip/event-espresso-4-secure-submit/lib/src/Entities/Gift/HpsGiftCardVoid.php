<?php

/**
 * Class HpsGiftCardVoid
 */
class HpsGiftCardVoid extends HpsGiftCardActivate
{
}
