<?php

/**
 * Class HpsGiftCardReversal
 */
class HpsGiftCardReversal extends HpsGiftCardActivate
{
}
