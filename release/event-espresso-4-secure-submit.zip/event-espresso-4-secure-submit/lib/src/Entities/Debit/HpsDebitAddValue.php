<?php

/**
 * Class HpsDebitAddValue
 */
class HpsDebitAddValue extends HpsAuthorization
{
}
