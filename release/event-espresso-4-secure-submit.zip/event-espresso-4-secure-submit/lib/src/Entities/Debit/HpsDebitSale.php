<?php

/**
 * Class HpsDebitSale
 */
class HpsDebitSale extends HpsAuthorization
{
}
