<?php

/**
 * Class HpsDebitReversal
 */
class HpsDebitReversal extends HpsAuthorization
{
}
