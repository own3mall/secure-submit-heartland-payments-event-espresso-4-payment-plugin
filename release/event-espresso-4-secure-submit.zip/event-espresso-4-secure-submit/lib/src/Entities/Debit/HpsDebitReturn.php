<?php

/**
 * Class HpsDebitReturn
 */
class HpsDebitReturn extends HpsAuthorization
{
}
