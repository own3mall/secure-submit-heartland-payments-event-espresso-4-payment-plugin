<?php

/**
 * Class HpsTransactionDetails
 */
class HpsTransactionDetails
{
    public $memo                = null;
    public $invoiceNumber       = null;
    public $customerId          = null;
    public $clientTransactionId = null;
}
