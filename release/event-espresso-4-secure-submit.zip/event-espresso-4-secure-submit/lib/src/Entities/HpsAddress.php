<?php

/**
 * Class HpsAddress
 */
class HpsAddress
{
    public $address = null;
    public $city    = null;
    public $state   = null;
    public $zip     = null;
    public $country = null;
}
