<?php

/**
 * Class HpsBatch
 */
class HpsBatch
{
    public $id               = null;
    public $transactionCount = null;
    public $totalAmount      = null;
    public $sequenceNumber   = null;
}
