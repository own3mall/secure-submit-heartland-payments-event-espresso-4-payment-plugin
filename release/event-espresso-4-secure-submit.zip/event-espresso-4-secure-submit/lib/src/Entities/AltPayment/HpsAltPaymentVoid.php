<?php

/**
 * Class HpsAltPaymentVoid
 */
class HpsAltPaymentVoid extends HpsAltPaymentResponse
{
}
