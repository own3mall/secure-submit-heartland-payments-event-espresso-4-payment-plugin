<?php

/**
 * Class HpsLineItem
 */
class HpsLineItem
{
    public $name        = null;
    public $description = null;
    public $number      = null;
    public $amount      = null;
    public $quantity    = null;
    public $taxAmount   = null;
}
