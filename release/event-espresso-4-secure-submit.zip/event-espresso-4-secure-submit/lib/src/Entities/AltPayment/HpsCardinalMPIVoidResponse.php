<?php

/**
 * Class HpsCardinalMPIVoidResponse
 */
class HpsCardinalMPIVoidResponse extends HpsCardinalMPIResponse
{
    /**
     * @param        $data
     * @param string $returnType
     *
     * @return mixed
     */
    public static function fromObject($data, $returnType = 'HpsCardinalMPIVoidResponse')
    {
        return parent::fromObject($data, $returnType);
    }
}