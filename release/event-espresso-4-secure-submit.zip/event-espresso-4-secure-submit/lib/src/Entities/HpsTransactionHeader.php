<?php

/**
 * Class HpsTransactionHeader
 */
class HpsTransactionHeader
{
    public $gatewayResponseCode    = null;
    public $gatewayResponseMessage = null;
    public $responseDt             = null;
    public $clientTxnId            = null;
}
